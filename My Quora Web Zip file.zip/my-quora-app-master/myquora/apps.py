from django.apps import AppConfig


class MyquoraConfig(AppConfig):
    name = 'myquora'
